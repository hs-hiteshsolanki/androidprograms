package com.hs.myapplication1

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.graphics.BitmapFactory
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)


        // Create and register notification channel api 26+
        val channelId = "My_Channel_ID"
        val notificationId = 1
        createNotificationChannel(channelId)

        val btnn = findViewById<Button>(R.id.btn)
        btnn.setOnClickListener {
            val notificationBuilder = NotificationCompat.Builder(this, channelId)
                .setSmallIcon(R.drawable.ic_launcher_background)
                .setContentTitle("Title: API LEVEL " + Build.VERSION.SDK_INT)
                .setContentText("Notification content text.")
                .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                .setStyle(
                    NotificationCompat.BigPictureStyle()
                        // Provide the bitmap to be used as the payload for the BigPicture notification.
                        .bigPicture(BitmapFactory.decodeResource(resources, R.drawable.graphics))

                        // Override the large icon when the big notification is shown.
                        .bigLargeIcon(BitmapFactory.decodeResource(resources, R.drawable.graphics))

                        // Overrides ContentTitle in the big form of the template.
                        .setBigContentTitle("Beautiful Bird")

                        // Set the first line of text after the detail section in the big form of the template.
                        .setSummaryText("This is big picture summary")
                )


            with(NotificationManagerCompat.from(this)) {
                notify(notificationId, notificationBuilder.build())
            }
        }
    }


    private fun createNotificationChannel(channelId: String) {
        // Create the NotificationChannel, but only on API 26+ (Android 8.0) because
        // the NotificationChannel class is new and not in the support library
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val name = "My Channel"
            val channelDescription = "Channel Description"
            val importance = NotificationManager.IMPORTANCE_DEFAULT

            val channel = NotificationChannel(channelId, name, importance)
            channel.apply {
                description = channelDescription
            }

            // Finally register the channel with system
            val notificationManager =
                getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            notificationManager.createNotificationChannel(channel)
        }
    }
}
